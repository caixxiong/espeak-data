# coding:utf-8

# 01 atexit模块
# 此模块只有一个函数就是register函数,用于注册回调函数,即程序退出时会
# 调用这些注册过的回调函数

# 用atexit.register注册的退出函数,是必须在整个程序退出的时候才执行的
# 并且程序退出时执行这些函数的顺序和注册它们顺序相反,而注册顺序则是
# register函数的执行顺序

import atexit
@atexit.register
def exit_fun1():
    print("in exit_fun1")
def exit_fun2():
    print("in exit_fun2")
atexit.register(exit_fun2)
def exit_fun3():
    print("in exit_fun3")
def exit_fun4():
    print("in exit_fun4")
    atexit.register(exit_fun3)
    #atexit.register(exit_fun2)
def main(argv=None):
    print("enter in main")
    exit_fun4()     # 注释掉此行后,exit_fun2,3不输出,因为它们没有被执行
    print("leave in main")

if __name__ == "__main__":
    main()
    print("end main")
'''out:
enter in main
in exit_fun4
leave in main
end main
in exit_fun3
in exit_fun2
in exit_fun1
'''
# 因为模块被导入的时候,第12和17行是会被执行的,所以注册的顺序为fun1,fun2,fun3
# 从而退出顺序与之恰好相反


# 02 tf.contrib.training.HParams()类
# Hparams(self, hparam_def=None, model_structure=None, **kwargs)

# HParams类用于简化超参的创建,通过在构造函数中传入关键字参数,则返回的HParams
# 对象就会用有以这些关键字命名的属性以及对应的值

# Hparams支持的超参数类型为:int,float,str,bool以及它们对应的列表类型

import tensorflow as tf
# 关键字参数不能加引号(因为不能是表达式),必须是普通标识符,但是直接打印hps对象
# 时,这些添加的属性会变成字符串类型(加上引号)
hps = tf.contrib.training.HParams(
    lr=0.3, hide_num=5, taco_gpu=4, mode='train') 
hps.lr, hps.mode #out: (0.3, 'train')
hps  #out: HParams([('hide_num', 5), ('lr', 0.3), ('mode', 'train'), ('taco_gpu', 4)])

# parse(self, values)
# 用于重写之前的超参,values是一个由逗号分割的name=value对构成的字符串
# 注意,str中出现的name必须是在hps对象中已经添加过的超参,也就是说此函数只能修改
# (重写),而不能新添加
hps.parse('lr=0.5, mode=eval') 
hps  #out: HParams([('hide_num', 5), ('lr', 0.5), ('mode', 'eval'), ('taco_gpu', 4)])

# override_from_dict(self, values_dict)
#添加和删除超参,此外hps还有get_hparam()和set_param(),但是直接给属性赋值或者获取属性名即可
hps.add_hparam(name='wav_gpu', value=4) # 不能添加已经存在的超参
hps #out: HParams([('hide_num', 5), ('lr', 0.5), ('mode', 'eval'), ('taco_gpu', 4), ('wav_gpu', 4)])
hps.del_hparam(name='taco_gpu') # 如果name不存在,则不修改hps
hps #out: HParams([('hide_num', 5), ('lr', 0.5), ('mode', 'eval'), ('wav_gpu', 4)])

# 类似于parse(),只是此处是传入一个字典,key是字符串类型
hps.override_from_dict({'lr':0.9, 'mode':'eval'})
hps #out: HParams([('hide_num', 5), ('lr', 0.9), ('mode', 'eval'), ('wav_gpu', 4)])

# parse_json(self, json_values),类似于parse(),此处传入一个json数据
hps.parse_json('{"lr":0.3,"mode":"test"}')  # 此处{}类的所有引号必须是双引号(json格式)
hps #out: HParams([('hide_num', 5), ('lr', 0.3), ('mode', 'test'), ('wav_gpu', 4)])


# values(self),以字典形式获取所有属性
hps.values() #out: {'lr': 0.9, 'hide_num': 5, 'mode': 'eval', 'wav_gpu': 4}

# 和argparse模块一起使用,可以接受命令行参数,并且来重写事先定义好的超参
import argparse
parser = argparse.ArgumentParser(description='the hparams parser')
parser.add_argument('--hparams', type=str,
                    help='comma sparated list of "name=value" pairs')
args = parser.parse_args()
hps.parse(args.hparams)
# python my_test.py --hparams='lr=1.0, wav_gpu=55', 此处后面必须有引号(单双均可),
# 其实如果--hparams后面的参数(即使是字符串),只要么有'=',则可以不加字符串的
# 注,最好用单引号,因为在shell中单引号会屏蔽掉其中的所有特殊字符,而双引号则不行
# 例如shell中有:wav="wav_gpu",则将wav_gpu=55,写成$wav=55且用双引号,则也可以的
print(hps) #out: [('hide_num', 5), ('lr', 1.0), ('mode', 'test'), ('wav_gpu', 55)]

