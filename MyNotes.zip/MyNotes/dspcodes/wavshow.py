#!/usr/bin/python
# -*- coding:utf-8 -*-

# 指定解释器的句子必须写在第一行, 并且#后不能有空格, 即第一行只能是#!/usr/bin/python

import sys
import numpy as np
import argparse as ae
import librosa as la
import librosa.display as dy
import scipy.signal as signal
import matplotlib.pyplot as plt


fig_x = 18
fig_y = 3
home = "/home/caixiong"
_mel_matrix = None

Hparams = type("Hparams", (object,), dict(
    n_fft=2048,
    hop_len=275,
    win_len=1100,
    n_mels=80,
    # sample_rate=22050,
    magnitude_power=2.,

    min_db=-100,    # 语谱最小分贝值
    ref_db=20,      # 语谱标准分贝值
    fmin=95,
    fmax=7600
))
hp = Hparams()      # Hparams是一个类型, hp是实例, dict中的值是Hparams拥有的类属性


# 求线性谱(对数谱)
def linearspect(wav, hp):
    stft = la.stft(wav, hp.n_fft, hp.hop_len, hp.win_len, pad_mode="constant")
    stft_m = np.abs(stft) ** hp.magnitude_power
    min_m = np.power(10, hp.min_db / 20)  # amp=10^(db/20), db=20*log10(amp)
    stft_db = 20 * np.log10(np.maximum(stft_m, min_m))  # stft_m to db
    # return stft_db - hp.ref_db
    print(stft_db.shape[0])
    return stft_db


# 求mel谱
def melspect(wav, hp, sr):
    global _mel_matrix
    assert hp.fmax <= hp.sample_rate // 2
    stft = la.stft(wav, hp.n_fft, hp.hop_len, hp.win_len, pad_mode="constant")
    stft_m = np.abs(stft) ** hp.magnitude_power
    if _mel_matrix is None:
        _mel_matrix = la.filters.mel(sr, hp.n_fft, n_mels=hp.n_mels, fmin=hp.fmin, fmax=hp.fmax)
    mel_m = np.dot(_mel_matrix, stft_m)
    min_m = np.power(10, hp.min_db / 20)
    mel_db = 20 * np.log10(np.maximum(mel_m, min_m))
    # return mel_db - hp.ref_db
    return mel_db


def plot_wav(wav, ax, sr, color="green", title=None, text=None):
    wav_plot = dy.waveplot(wav, sr=sr, ax=ax, linewidth=0.75, color=color)
    if text is not None:
        ax.set_xlabel(text)
    if title is not None:
        ax.set_title(title)  # wav文件名
    return wav_plot


def plot_spectrum(spect, ax, sr, is_lin=True, win_len=1100, cmap=None, title=None):
    top = spect.shape[0] * sr / win_len if is_lin else spect.shape[0]
    extent = [0, spect.shape[1], 0, top]
    im = ax.imshow(np.rot90(spect.T), cmap=cmap, extent=extent, aspect='auto', interpolation='none')  # 对转置逆时针转90度
    if title is not None:
        ax.set_title(title)
    return im


def prepare_data(wav_files, show_type, sr=None, mono=True, offset=.0, duration=None, pre_emphasis=.0):
    accepted_type = ["wav", "lin", "mel"]
    wav_files = [wav.strip().replace("~", home, 1) for wav in wav_files.split("|")]  # 多个wav文件时, 用|隔开, 但是shell中|是代表pipe, 所以记得需要转义用 \|
    show_type = [x for x in set(show_type.split("|")) if x in accepted_type]  # show_type默认是wav

    datas = []
    srs = []
    for wav_file in wav_files:
        wav, sr = la.load(wav_file, sr=sr, mono=mono, offset=offset, duration=duration)
        if pre_emphasis != .0:
            wav = signal.lfilter([1., -pre_emphasis], [1], wav)
        data = []
        if "wav" in show_type:
            data.append(wav)
        if "lin" in show_type:
            data.append(linearspect(wav, hp))
        if "mel" in show_type:
            data.append(melspect(wav, hp, sr))
        datas.append(data)
        srs.append(sr)
        sr = None   # 之前没有写此句, 导致多个文件时, 后面的文件的采样率会变成和第一个文件一样的了
    return datas, srs


def prepare_axes(datas_shape, show_type=["wav", "lin", "mel"]):
    wavs_num = datas_shape[0]
    type_num = datas_shape[1]
    step = 2 if type_num > 1 and "wav" in show_type else 1  # 如果要同时画wav和语谱, 则一个文件需要两行画板, 否则只需要一行
    n_rows = step * wavs_num
    cnt = 0   # cnt用于记录lin和mel是否同时出现或者同时都不出现
    for x in ["lin", "mel"]:
        if x in show_type:
            cnt += 1

    fig, axs = plt.subplots(n_rows, 2, figsize=(fig_x, fig_y * n_rows), squeeze=False)    # subplot_kw={"position": [0.03, None, 0.96, None]})
    gs = axs[0, 0].get_gridspec()       # 获取布局
    for i in range(0, axs.shape[0], step):
        axs[i, 0].remove()
        axs[i, 1].remove()
        axs[i, 0] = fig.add_subplot(gs[i, :])       # 将一行两个子图改成一个子图
        axs[i, 1] = None    # 将第二个元素清空
        if cnt == 1:        # cnt=1说明恰好有一个语图要画, 此时需要去掉一个不需要的子图
            axs[i + 1, 1].remove()
    return fig, axs


def main_plot(args):
    # datas是一个二维列表, 行数wave files num, 列数是每个需要画的图的个数, 元素是一个np数组
    wav_titles = [line.strip().split("/")[-1] for line in args.wav_files.split("|")]   # 将最终的文件名作为title
    texts = [None] * len(wav_titles) if args.texts is None else [line.strip() for line in args.texts.split("|")]   # 文本
    datas, srs = prepare_data(args.wav_files, args.type, args.sr, args.mono, args.offset, args. duration, args.preemphasis)
    fig, axs = prepare_axes([len(datas), len(datas[0])], show_type=args.type)  # axs是一个二维np数组, 行数是文件数(或者*2), 列数是2
    mutil_factor = 2 if len(datas[0]) > 1 and "wav" in args.type else 1        # 如果同时画wav和语谱, 则一个wav文件需要两行画板
    for i in range(len(datas)):
        j = i * mutil_factor
        data = datas[i]
        if axs[j, 1] is None:   # 需要画wav
            plot_wav(data[0], axs[j, 0], sr=srs[i], title=wav_titles[i], text=texts[i])
            j = j + 1
        for x, ax in zip(data[1:], axs[j]):  # 剩下的图(如果有的话)画在第j+1行
            is_lin = x.shape[0] > 300   # 假设mel的维度小于300, 线性谱的大于300
            im = plot_spectrum(x, ax, sr=srs[i], is_lin=is_lin, title=wav_titles[i])
            fig.colorbar(mappable=im, shrink=0.65, ax=ax)
    fig.tight_layout()
    plt.show()


def main():
    parser = ae.ArgumentParser(description="wavshow.py for wav show")
    parser.add_argument("wav_files", default=None, help="wave file names str split by '|', needed use '\|'")
    parser.add_argument("--type", "-T", default="wav", help="the show type of wav files: wav, mel, lin, saperate by '|'")
    parser.add_argument("--sr", default=None, help="the sample rate of wave files")
    parser.add_argument("--texts", default=None, help="the corresponding texts of waves with '|' split")
    parser.add_argument("--mono", type=bool, default=True, help="whether is mono or mutil channel")
    parser.add_argument("--offset", type=float, default=.0, help="the offset position of wav to show")
    parser.add_argument("--duration", type=float, default=None, help="the duration of wav to show")
    parser.add_argument("--preemphasis", type=float, default=.0, help="the preemphasis cofficent should in [0.9, 1.0]")  # 系数越大, 则加重效果越明显
    args = parser.parse_args()

    if args.wav_files is None:
        print("exited due to no wav files input!!")
        return
    main_plot(args)


if __name__ == "__main__":
    sys.exit(main())
