# -*- coding: utf-8 -*-

import os
import numpy as np
import librosa as la
import tensorflow as tf
import matplotlib.pyplot as plt

hparams = tf.contrib.training.HParams(
    n_fft=2048,
    hop_len=275,
    win_len=1100,
    n_mels=80,
    sample_rate=22050,
    magnitude_power=2.,

    min_db=-100,    # 语谱最小分贝值
    ref_db=20,      # 语谱标准分贝值
    fmin=95,
    fmax=7600
)
_mel_matrix = None


# 画loss和时间等折线图
def draw_plot(ax, ys, title, legends, x=None, x_label=None, y_label=None):
    # ax是本次的子图, ys必须是一个2维列表, (num_lines, time_len)
    for y, legend in zip(ys, legends):
        if x is None:
            ax.plot(y, linewidth=0.7, label=legend)   # 也可以此处不传label, 在ax.legend()中传入labels=legends
        else:
            ax.plot(x, y, linewidth=0.7, label=legend)
    ax.set_title(title)
    ax.set_xlabel(x_label)
    ax.set_ylabel(y_label)
    ax.legend(loc="upper right")    # 或者是loc=1
    # ax.legend(loc="upper right", labels=legends)


# 读取经过awk提取后的训练时的日志数据
def data_read(files, cols=None):
    # 文件的格式很重要, 每一行的列数必须相同, 否则此函数会出错的
    # files是文件名列表, cols是文件中需要提取的列的列表
    files = files if type(files) == list else [files]
    datas = []
    for ff in files:
        with open(ff) as f:
            data = f.readlines()
        data = np.array([line.strip().split() for line in data])
        # print(data.dtype, ff)  # dtype是字符串, 长度为17, np会把字符串的最大长度设置为字符串的长度, 所以
        cols = range(data.shape[-1]) if cols is None else cols
        for col in cols:  # 对需要提取的列进行split(), 如: loss=0.56, 去掉'loss='
            data[:, col] = np.array([x.split("=")[-1] for x in data[:, col]])
        data = data.astype(np.float32)  # astype()函数不会改变原数组, 所以需要将结果赋值给data
        datas.append(data)
    return datas  # 是一个列表, 每个元素是一个文件中的数据(n*m的np数组, n是文件的行数, m是列数)


# 求线性谱(对数谱)
def linearspect(wav, hp):
    stft = la.stft(wav, hp.n_fft, hp.hop_len, hp.win_len, pad_mode="constant")
    stft_m = np.abs(stft) ** hp.magnitude_power
    min_m = np.power(10, hp.min_db / 20)  # amp=10^(db/20), db=20*log10(amp)
    stft_db = 20 * np.log10(np.maximum(stft_m, min_m))  # stft_m to db
    # return stft_db - hp.ref_db
    return stft_db


# 求mel谱
def melspect(wav, hp):
    global _mel_matrix
    assert hp.fmax <= hp.sample_rate // 2
    stft = la.stft(wav, hp.n_fft, hp.hop_len, hp.win_len, pad_mode="constant")
    stft_m = np.abs(stft) ** hp.magnitude_power
    if _mel_matrix is None:
        _mel_matrix = la.filters.mel(hp.sample_rate, hp.n_fft, n_mels=hp.n_mels, fmin=hp.fmin, fmax=hp.fmax)
    mel_m = np.dot(_mel_matrix, stft_m)
    min_m = np.power(10, hp.min_db / 20)
    mel_db = 20 * np.log10(np.maximum(mel_m, min_m))
    # return mel_db - hp.ref_db
    return mel_db


# 画语谱
def plot_spect(spect, path, title=None):
    fig = plt.figure(figsize=(8, 4))
    ax = fig.add_subplot("111")
    im = ax.imshow(np.rot90(spect.T), aspect='auto', interpolation='none')  # 对转置逆时针转90度
    ax.set_title(title, fontsize=12)
    fig.colorbar(mappable=im, shrink=0.65, ax=ax)
    plt.tight_layout()
    plt.savefig(path, format='png')
    plt.close()


# 画Terminal_trian_logs
def main_plot_logs():
    base_dir = '/home/caixiong/TTS/wave_out/experiment'
    files = ['layers11/layers11.log', 'out30/out30.log', 'out2/out2.log']
    files = [os.path.join(base_dir, x) for x in files]
    datas = data_read(files)

    cols = [1, 3]     # 指定文件中实际需要画的列号, 本次的log文件是4列的(步数, 每步的时间, loss, avg_loss), 只画时间和avg_loss
    titles = ['Training Time Per Step', 'Average Loss Per Step']
    y_labels = ['time', 'loss']
    legends = ['layers11', 'out30', 'out2']

    fig_n = np.ceil(np.sqrt(len(cols)))
    x, y = (fig_n, fig_n) if len(cols) > 3 else (len(cols), 1)  # fig布局的行和列数
    fig, axs = plt.subplots(x, y)
    for col, ax, title, y_label in zip(cols, axs, titles, y_labels):
        ys = [data[:, col] for data in datas]   # 获取每个文件的第col列
        draw_plot(ax, ys, title, legends, x_label="step", y_label=y_label)
    fig.tight_layout()
    plt.show()
    # plt.savefig(os.path.join(base_dir, "logs.png"), format="png")


# 画语谱图
def main_plot_spect():
    base_dir = "/home/caixiong/TTS/wave_out/experiment"
    # wav_file = "out30/wavenet-audio-500000_out30_2.wav"
    # wav_file = "layers11/wavenet-audio-500000_layers11_2.wav"
    wav_file = "out2/wavenet-audio-500000_out2_2.wav"
    wav_file = os.path.join(base_dir, wav_file)
    wav_file = "/home/caixiong/rap/wavs/GG.wav"
    wav, sr = la.load(wav_file, sr=None)
    lspect = linearspect(wav, hparams)
    mspect = melspect(wav, hparams)
    lpath = wav_file.split(".")[0] + "_linear.png"
    mpath = wav_file.split(".")[0] + "_mel.png"
    # title = "There's a way to measure the acute emotional intelligence that has never gone out of style."
    title = "President Trump met with other leaders at the Group of 20 conference."
    plot_spect(lspect, lpath, title)
    plot_spect(mspect, mpath, title)

    plt.specgram(wav, NFFT=1100, pad_to=2048, Fs=22050, noverlap=1100 - 275, scale='dB', mode="default", scale_by_freq=True)
    plt.show()


if __name__ == "__main__":
    main_plot_spect()
    # main_plot_logs()
