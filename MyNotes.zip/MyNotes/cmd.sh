#encoding:utf-8

# 01 配置系统自动选择的python版本  
sudo update-alternatives --install /usr/bin/python python /usr/bin/python2.7 1
sudo update-alternatives --install /usr/bin/python python /usr/bin/python3.6 2
update-alternatives --list python
update-alternatives --config python

# 02 后台运行命令
python aa.py > out.file 2>&1 &
nohup python aa.py > out.file 2>&1 &    # 退出shell终端时继续执行命令

# 03 计算哈希值
md5sum filename
sha1sum filename

# 04 下载命令
wget option url
-b 后台下载
-c 继续下载
-P 指定保存的路径

# 05 查看端口命令
netstat -ap | grep process_name # 查看进程对应的的端口号,ap前面必须有-
lsof -i:port_num    # 查看该端口对应的pid和程序名
ss -lptu    #类似于netstat,但是此命令会显示进程名

# 06 进入applications目录
nautilus /usr/share/applications    # nautilus被卸载了
nemo /usr/share/applications        # 用nemo代替了

# 07 调节屏幕亮度
sudo setpci -s 00:02.0 F4.B=FF # [00, FF], 00:02.0 是屏幕设备的地址
lspci | grep -i vga  # 查看屏幕设备

# 08 查看磁盘使用情况
df -h   # 查看整个磁盘的使用情况
df -h /usr  # 查看分区/usr的使用情况,如果/usr不是单独分区的,则结果是/分区的使用情况
    # df -h your_dir命令中,your_dir必须是单独分区的,其实此命令就是显示df -h的某一行
du --max-depth=1 -h /usr    # 查看目录/usr的使用情况,此条命令可以查看usr的实际使用量
du --max-depth=1 -h /       # 查看根目录下所有子目录的使用情况
    # df是查看指定分区的使用情况,如果给的是目录,则是该目录所在分区的使用情况
    # du是查看指定目录的使用情况
du -sh /usr # 计算/usr目录的占用空间大小,结果和du --max-depth=1 -h结果的最后一行是一样的
df -h / # 查看根分区占用大小,/下单独分区的目录不算在内的,如/home, /boot
df -h /home # 查看/home分区大小
df -h /boot # 查看/boot分区大小
du -sh /usr # 查看/usr目录占用大小
du -sh /usr/bin # 查看/usr/bin目录占用大小
du -sh /home    #效果与df -h /home一样的

# 09 弹出u盘
df -a   # 查看U盘是在/dev/的哪个目录下,如/dev/sda1
sudo eject /dev/sda1    # 弹出u盘

# 10 查看可用的显卡驱动程序
# 直接从update软件中下载也很快的,前提是把网络设置好了
sudo add-apt-repository ppa:graphics-drivers/ppa    # 安装nvidia的apt源
sudo apt update
ubuntu-drivers devices  # 查看只要这条命令即可
nvidia-settings  # 打开设置窗口,在Prime Profiles中可以配置使用inter集显还是nvidia独显
nvidia-smi       # 查看显卡使用情况 
sudo apt autoremove --purge nvidia* # 删除显卡驱动程序和管理程序
lspci -vnn | grep -i VGA -A 12 # 查看系统中安装好的显卡(显卡驱动程序)
lspci -k | grep -A 2 -i "VGA"  # 同上

# 11 解决apt出现无法获得锁的错误
# 方法一
ps -aux | grep apt  # 查看目前正在占有apt锁的进程pid, 或者是ps aux 无-
sudo kill pid       # 杀死该进程即可
# 方法二
ps -e | grep apt    # -e选项显示pid和进程名
sudo killall apt    # 知道完整命令名后用killall删除

# 12 指定忽略某个软件的更新
apt-mark hold xxx   # 在apt upgrade时,xxx不会被更新了
apt-mark unhold xxx # 解除hold,使得xxx可以更新
dpkg --get-selections xxx # 查看xxx的锁定状态:hold是锁定,install是没有锁定

# 13 pip指定安装源
pip install -i https://pypi.tuna.tsinghua.edu.cn/simple numpy -U    # 从指定源安装最新版本的numpy
pip config set global.index-url https://pypi.tuna.tsinghua.edu.cn/simple #　指定默认源,此命令会写pip.conf文件

# 14 ipconfig /rlease /renew 的ubuntu版本
sudo dhclient -r    # 重新获得ip地址并关闭dhcp client,此命令执行后将无法上网
sudo dhclinet       # 重新开启dhcp client,执行完此命令后才能上网
sudo dhclient -x    # 关闭dhcp client,但是不释放ip地址

# 15 修改ubuntu登录界面
cd /etc/alternatives/   # 进入配置目录
ls -lh | grep gdm3.css  # 查看gdm3.css这个链接文件指向的真实文件
cd /usr/share/gnome-shell/theme/Yaru/ # gdm3.css目前指向gnome-shell.css
cp gnome-shell.css gnome-shell.bak    # 备份一下这个文件
vim gnome-shell.css     # 找到lockDialogGroup,修改成现在的内容即可
# 注: 前面几步均已配置好,现在如果要修改登录界面,只需最后一步中将file:///后的文件地址修改即可
# 具体可以看这个网址https://zhuanlan.zhihu.com/p/36470249

# 16 设置点击dock图标,最小化应用
gsettings set org.gnome.shell.extensions.dash-to-dock click-action 'minimize'

# 17 打开ubuntu软件中心
gnome-software %U

# 18 为文件创建link(硬链接和软链接均可创建)
# 硬链接也保存了i-node信息的,都指向相同的文件内容,它和原来的文件地位等同,只是路径和名字不同
#   删除某一个文件后,只要指向i-node的文件数目>=1,则文件不会删除
# 软链接它本身是一个文件,这个文件的内容是它指向目标文件的绝对文件名,可以对软链接文件进行编辑
#   此时同样会修改它指向的目标文件,但是如果目标文件修改了名字或者移动到其他目录下了,则该软链
#   接将会失效,因为它的文件内容中存放的文件名已经找不到源文件了,硬链接不会有这个问题
# 总结: 硬链接存放的是i-node信息,软链接存放的是源文件的绝对路径

# ln TARGET LINK_NAME   # TARGET是源文件,LINK_NAME是硬链接文件名
ln cc.cpp GG    # 为cc.cpp创建硬链接,名字为GG,此时GG和cc.cpp在同一目录下
ln cc.cpp tf/GG # 此时GG在tf目录下,如果tf/aa/目录不存在的话,则ln cc.cpp tf/aa/GG非法
ln ~/cc.cpp     # 此用法是cc.cpp不能在当前目录下,ln在当前目录下创建一个同名的硬链接cc.cpp

ln cc.cpp cmd.sh killpid.sh tf/ # 为多个文件创建硬链接,此时最后一个参数是一个目录
ln -t tf cc.cpp cmd.sh killpid.sh  # 和上一条命令等价

ln -s cc.cpp GG # 加-s选项,则是创建软链接(symbolic link),一般用于链接可执行程序

# 19 打开utorrent
utserver -settingspath /opt/utorrent-server-alpha-v3_3/ &
# 浏览器访问地址: 127.0.0.1:8080/gui

# 20桌面图标最小化
gsettings set org.gnome.shell.extensions.dash-to-dock click-action 'minimize'

# 21 ppa和升级软件
sudo add-apt-repository ppa:user/ppa-name    # 添加ppa
sudo add-apt-repository -r ppa:user/ppa-name # 删除ppa
sudo apt update
sudo apt list --upgradable -a     # 查看可更新的软件以及版本号
sudo upgrade package-name=ver-num # 根据刚才的版本号,或者需要的版本号升级该软件

# 22 转换音频格式
avconv -i xx.m4a -ar 22050 xx.wav
# 源码安装libav, 网上的教程sudo apt install libav-tools行不通, ubuntu上没有该源
git clone git://git.libav.org/libav.git # 下载有点慢,可以直接上github网站上下载
cd libav    # 网上下载的压缩包需要先解压,然后进入目录, https://github.com/libav/
./configure # 如果出现没有nasm, yasm的错误,就sudo apt update && sudo apt nasm yasm
make
make install

# 23 update grub
sudo update-grub
sudo grub-install /dev/nvme0n1	# 因为我的ubuntu安装在nvme0n1盘上

# 24 系统配置
## 00 显卡配置
# 先禁用NVIDIA驱动: 在grub中进入recovery模式,然后将"ro"后面的都删掉,改成ro quiet splash nouveau.modeset=0,再按f10进入系统
# 安装NVIDIA驱动:
sudo add-apt-repository ppa:graphics-drives/ppa
sudo apt update
sudo apt install nvidia-390
reboot  # 重启后可能没有nvidia-settings,需要再手动安装一下

## 01 pip ipython trash-cli的安装
# pip,ipython,flake8,pyflakes,trash-cli等的安装基本上都一样,因为它们的模式都是一个python库+一个调用该库的python可执行程序,
# 都是需要先用apt安装该命令,然后再用pip升级该库,或者自己手动安装该库

# pip安装
sudo apt install python3-pip        # 先用apt安装一个较旧的pip版本
pip3 install -U pip		# 将pip升级到最新版本,此时使用pip会出现找不到main模块的错误,这是因为老版本的pip执行程序不兼容新版本
sudo vim /usr/bin/pip3	# 修改pip3文件,可以直接copy我备份的pip文件,或者参考我的博客,同样的方法可以安装pip2: python-pip
sudo cp pip3 pip		# 创建pip文件,把第一行的python3改成python
sudo apt remove --purge python3-pip	# 安装好后删除旧版本
# ps: 在升级完pip后,会在~/.local/bin下生成pip的可执行文件,但是可能这个目录又不在PATH中,所以需要好动将之加入到PATH中,我是在
#   bashrc中加入的, 对于flake8,pyflakes,ipython等这些用pip安装后也是在这个目录下生成可执行文件的
# ps: 安装python-pip后,可能会由于系统默认的python时python3,导致pip2这个程序执行失败,此时将pip2第一行改成python2或者将系统默认
#   pythhon改成python2,然后在pip2 install -U pip对pip2进行更新,注意,之后可以删掉python-pip,但是会导致python2也被删掉的,所以还
#   需要手动安装一下python2
# ps: 最后最好将.local/bin下的可执行文件复制到/usr/bin下,因为有可能需要用sudo执行这些文件,如果不放的话,sudo会找不到的,比如用
#   pip安装shadowsocks时,由于需要用sudo pip安装,所以pip必须放在/usr/bin下

# ipython安装
pip install --user ipython	# 安装ipython的库, 将备份的ipytho文件copy到/usr/bin/即可(也可用apt安装下ipython可自动获得ipython文件)

# trash-cli安装
sudo apt install trash-cli	# 如果系统默认用python2的话,则已经可用了
# python3需要源码安装
git clone https://github.com/andreafrancia/trash-cli.git
cd trash-cli
python setup.py install --user
# 需要注意的是, 此时系统中有两份trash-cli,一份在/usr/bin下,是由apt安装的,另一份在.local/bin下,是python3安装的,这两组命令的接口
# 还不太一样,apt中的是restore-trash,而.local/bin下的是trash-restore,所以我直接把apt安装的trash-cli卸载了,保持以前的习惯
# ps: 最简单的方式,就是先把我的trash-cli备份文件夹copy过来,然后执行python setup.py install --user即可

## 02 vim配置
mkdir -p ~/.vim/bundle
cp /path/to/vimrc.bak ~/.vimrc # 将备份的vimrc文件放在~目录下
git clone https://github.com/VundleVim/Vundle.vim.git ~/.vim/bundle/Vundle.vim # 我直接备份了该文件夹,下次直接copy就行
vim +PluginInstal +qall # 安装vimrc中的插件, 也可以先打开vim,然后再PluginInstall
# ps: git命令是用于安装Vundle的,也就是说只要把插件放在了bundle目录下,就算安装了该插件了
# 经过上面的操作,所有插件都可以用了,但是语法检查插件还不能正常工作,因为还没有pyflake8,pyflakes,pylint
pip instal flake8       # 安装flake8
pip install pyflakes    # 安装pyflakes
pip install pylint      # 安装pylint, 其实只要安装了flake8即可,因为vimrc文件中只允许使用flake8
# ps: 上面的三个命令会直接被安装在.local/bin中,因为我本地的PATH中包含了.local/bin,所以可以直接运
# 行这三个命令,而在服务器上因为.local/bin没有被添加在PATH中,就不能直接使用,此时vim的syntastic也就
# 不能正确使用这个三个命令来检查语法,所以在服务器上,可以把这三个执行文件放在~/.bin目录下即可
# 本地也可以用apt来安装它们

## 03 shadowsocks配置
sudo pip install shadowsocks    # 此处必须用sudo安装,此时sslocal命令被放在/usr/local/bin/下
sudo vim /usr/local/lib/python3.6/dist-packages/shadowsocks/crypto/openssl.py
#:%s/cleanup/reset/gc           # 将cleanup替换成reset即可,一共有两处再52和111行
# pip安装shadowsocks时,最好是用sudo安装,因为sslocal这条命令需要sudo权限,如果安装在~/.local/bin下
# 的话,则sudo是找不到该命令的
# 配置好后,需要先开启系统手动代理,设置socks为127.0.0.1, 1080
# 然后打开chrome登录同步,等扩展程序都同步过来后,打开switchy-omega扩展程序,导入备份中的switchy-omega.bak文件即可

## 04 修改登录界面
sudo nautilus /usr/share/backgrounds    # 打开系统壁纸文件夹
# 选择一张喜欢的,给它重命名一下,然后在tweak里边设置即可
sudo vim /etc/alternatives/gdm3.css # 将lockDialogGroup修改成下面的内容即可,图片选喜欢的
'''
#lockDialogGroup {
  background: #2c001e url(file:///usr/share/backgrounds/zm01.jpg);         
  background-repeat: no-repeat;
  background-size: cover;
  background-position: center; }
'''

## 05 其他软件
sudo apt install workrave
sudo apt install goldendict   # 有道网址: http://dict.youdao.com/search?q=%GDWORD%&ue=utf8
sudo apt install okular
sudo apt install chrome-gnome-shell # 安装chrome的gnome-shell扩展,没有此程序,则chrome的gnome-shell扩展程序没法用

## 06 一些设置
sudo apt-mark hold fcitx nautilus   # 保持nautilus和fcitx不要更新
gsettings set org.gnome.shell.extensions.dash-to-dock click-action 'minimize' # 设置单击为最小化图标
sudo apt install gir1.2-gtop-2.0 gir1.2-networkmanager-1.0 gir1.2-clutter-1.0 # 对system-monitor安装后缺少的库进行安装
ssh-keygen      # 生成rsa密钥对, 存放公钥的文件时authorized_keys

## 07 系统备份
tar -cvpzf /media/caixiong/caixiong/ubuntu_backup_20190501.tar.gz --exclude=/proc --exclude=/tmp --exclude=/lost+found --exclude=/media --exclude=/mnt --exclude=/run --exclude=/boot --exclude=/home /
tar -cvpzf /media/caixiong/caixiong/home_backup_20190501.tar.gz /home
tar -cvpzf /media/caixiong/caixiong/boot_backup_20190501.tar.gz /boot
# 由于备份/时排除了一些目录,所以如果是想先删除/再恢复的话,需要把这些目录再创建进来,包括/home和/boot的恢复
# 如果恢复前不删除/,则tar只是会将压缩文件中已经有的目录替换/下的相同目录,而不会删除压缩文件中没有的目录
# 参考文献: https://blog.csdn.net/qq_35523593/article/details/78545530

# 25 python相关
## 01 安装pyaudio库
sudo apt install python3-pyaudio  # 用pip安装会出错的
sudo pacman -S python3-pyaudio    # 在服务器上安装, 服务器上只有pacman可以用sudo权限
passwd cai-x18  # 修改登录密码, 不用sudo权限也可以修改的

## 02 awk过滤loss, 计算时间平均值
awk '/ Step /{print $4, $5, $7, $8}' Terminal_out30 | awk -F ',' '{print $1, $2}' | awk -F ']' '{print $1}' | awk -F '[' '{print $1, $2}' > out30.log
awk '{if(NR>=200000){sum += $2}} END{print sum/(NR-200000)}' layers11.log

## 03 ImportError: No module named  tkinter
sudo apt-get install python3-tk

## 04 安装强制对齐工具:aeneas
# 先下载处理依赖的sh文件
wget https://raw.githubusercontent.com/readbeyond/aeneas/master/install_dependencies.sh
chmod + x install_dependencies.sh
./intall_depencies.sh
pip install aeneas --user   # 如果不先安装依赖的话, 此处会出错

# 网址: https://pypi.org/project/aeneas/1.4.0.0/#linux

# 26 百度云下载
cd ~/tmp/webui-aria2/
node node-server.js &  # 打开aria2c的web-ui界面, 需要在浏览器访问localhost:8888
sudo aria2c --conf-path=/home/caixiong/.config/aria2c.conf  # 打开aria2c下载服务端口
# 下一步是登录百度云网页, 然后选择需要下载的文件, 然后点击导出下载, 选择aria-rpc即可, 导出下载时baidu-exporter插件提供的
# 如果出现下载错误, 很有可能是因为没有保存而直接下载的, 需要先保存, 然后在下载 

# 27 wps无法登录和符号缺失问题
# 无法登录
cd /proc
tree -af . | grep -i kingsoft  # 找到包含kingsoft的文件夹(是一个数字命名的)
sudo rm -r the_finded_dir  # 如果出现权限错误, 就killp wps && killp wpp把wps和wpp程序全部关闭
# 符号缺失, 因为之前无法登录, 我重新装了一下wps, 导致之前的字体和符号文件没了
sudo mkdir /usr/share/fonts/wps-office
sudo cp ~/apps/wps/wps_symbol_fonts.zip /usr/share/fonts/wps-office
cd /usr/share/fonts/wps-office
unzip wps-office  # ok, 此时还是有字体缺失了

# 28 unix和win文件转换
# 如果文件中显示的是, 则在vim中输入:%s//\r/g即可, 注意是按ctl+v和ctl+m, 而不是^M两个字符, ctl+M是回车键
# 用工具: dos2unix和unix2dos, 但是这两个工具似乎没什么效果

#=======================================================================================================#

## 01 shell比较运算符, 只支持数值比较,不支持字符串比较
[ -eq -ne -gt -lt -ge -le ] # =, !=, >, <, >=, <=
#ps: 字符串比较用 !=, ==, =

## 02 shell数组(只支持一维数组)
arr=(1 2 "3" "A")   # 定义数组用()括起来,用' '或者'\n'分隔,下标从0开始
arr[0]=1;arr[1]=2;arr[2]="3";arr[3]="A" # 也可用下标定义数组,效果与上面一样的
echo ${arr[0]}      # 获取arr[0]的值,注意花括弧不能省,因为$arr是等于1的,如果省略,则$arr[0]输出1[0]
echo ${arr[@]},${arr[*]}     # 用于获取数组的所有元素
echo ${#arr[@]},${#arr[*]}   # 获取数组长度 
# ps: 虽然arr[2]="3",但是同样可以进行数学运算的

# 遍历数组
for x in ${arr[@]};do
    echo $x                  # 每个echo后会输出一个换行
done

for((i=0; i<${#arr[@]}; i++));do
    printf ${arr[i]},$i,    # 不会输出换行, 单独使用i时,要加$
done

echo "hehhe"
for i in ${!arr[@]};do      # !arr[@]是取数组所有索引的意思
    printf ${arr[i]}        # i作为数组索引时,i和$i均可
    printf $i               # 单独使用时需要加$
done
echo "hehehe"

i=0
while [ $i -lt ${#arr[@]} ];do
    printf ${arr[$i]}       # 不能用print, print的输入是文件
    let i++
done
echo 

# for循环的一个简写
for i in {1..10};do
    printf $i               # 12345678910
done
echo

for x in aa bb cc dd;do
    printf $x              # aabbccdd
done


## 03 shell整数算数运算

# let "表达式"              # 如果表达式比较复杂,最好是用""括起来
# 在表达式内变量可以直接访问,不需要加$
# 表达式内可以定义新的变量,并且新变量自动初始值为0
# **, %, +, -, *, /, +=, -=, *=, /=, ++, --

a=10
let "a += 10"; echo $a      # 20

# (()), 用法和let完全相同,感觉(())比用let更简洁
((a = a**2)); echo $a       # 400

## 04 shell变量
aa=100                            # 显示定义变量
for file in $(ls .);do echo;done  # 隐式定义变量,此时变量file在for循环外也可使用

echo "I am ${aa}xixi"  # 使用变量时最好加{},用于解释器确定变量边界,如果没有{},
# 则aaxixi被解释器认为是一个变量,从而输出空值

readonly aa     # 将aa设置为readonly的,则接下来不允许修改aa,即不允许对aa重新赋值
unset aa        # 删除变量,不能删除readonly变量

# 系统变量
$n  # 传递给函数或本程序的参数,从$1开始
$0  # 本程序的名字
$*  # 全部参数列表
$@  # 同$*, 但是不适用与IFS环境变量
$?  # 上一个命令的退出状态,0是正常退出,非0则非正常退出,退出码的范围是[0,255]
$$  # 本进程的pid
$!  # 上一个命令的pid

# 将命令的执行结果输出到变量,两种方式
out=`echo "123"`
((out += 100)); echo $out       # 223
out=$(ls | grep sh); echo $out  # cmd.sh killPid.sh

# 1,118s/\n/\r#/
# 1,118s/\n#/\r/
